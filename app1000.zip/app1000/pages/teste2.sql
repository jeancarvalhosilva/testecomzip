select 'teste2' from dual
union
select 'teste3' from dual;